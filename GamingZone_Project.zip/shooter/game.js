const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const bestEl = document.getElementById('best');
const overlay = document.getElementById('overlay');
const titleEl = document.getElementById('overlay-title');
const textEl = document.getElementById('overlay-text');
const startBtn = document.getElementById('start');

let keys = {};
let running = false;
let score = 0;
let lives = 3;
let best = Number(localStorage.getItem('gz-best') || 0);
let lastTime = 0;
let enemyTimer = 0;
let shotTimer = 0;
let player, bullets, enemies, stars;

bestEl.textContent = String(best).padStart(6, '0');

function resetGame() {
  score = 0; lives = 3; enemyTimer = 0; shotTimer = 0;
  player = { x: 450, y: 485, w: 34, h: 38, speed: 330 };
  bullets = []; enemies = [];
  stars = Array.from({length:100}, () => ({x:Math.random()*canvas.width,y:Math.random()*canvas.height,s:Math.random()*2+0.5,v:20+Math.random()*70}));
  updateHud();
}
function updateHud() {
  scoreEl.textContent = String(score).padStart(6, '0');
  livesEl.textContent = lives > 0 ? ('♥ '.repeat(lives)).trim() : '—';
  bestEl.textContent = String(best).padStart(6, '0');
}
function startGame() {
  resetGame(); running = true; overlay.classList.add('hidden'); lastTime = performance.now(); requestAnimationFrame(loop);
}
function endGame() {
  running = false;
  if (score > best) { best = score; localStorage.setItem('gz-best', String(best)); }
  updateHud();
  titleEl.textContent = 'MISSION OVER';
  textEl.textContent = `You scored ${score} points. Ready to fly again, pilot?`;
  startBtn.textContent = 'RETRY MISSION';
  overlay.classList.remove('hidden');
}
function drawShip(x,y) {
  ctx.save(); ctx.translate(x,y);
  ctx.shadowBlur=18; ctx.shadowColor='#5ff5e6';
  ctx.fillStyle='#5ff5e6'; ctx.beginPath(); ctx.moveTo(0,-22); ctx.lineTo(17,16); ctx.lineTo(0,9); ctx.lineTo(-17,16); ctx.closePath(); ctx.fill();
  ctx.fillStyle='#e8ffff'; ctx.beginPath(); ctx.moveTo(0,-12); ctx.lineTo(5,7); ctx.lineTo(-5,7); ctx.closePath(); ctx.fill();
  ctx.fillStyle='#a68bff'; ctx.fillRect(-5,15,3,8); ctx.fillRect(2,15,3,8);
  ctx.restore();
}
function drawEnemy(e) {
  ctx.save();ctx.translate(e.x,e.y);ctx.shadowBlur=14;ctx.shadowColor='#ff4e78';ctx.fillStyle='#ff4e78';
  ctx.beginPath();ctx.moveTo(0,17);ctx.lineTo(18,-9);ctx.lineTo(7,-6);ctx.lineTo(0,-15);ctx.lineTo(-7,-6);ctx.lineTo(-18,-9);ctx.closePath();ctx.fill();
  ctx.fillStyle='#fff0f4';ctx.fillRect(-3,-3,6,4);ctx.restore();
}
function hit(a,b) { return Math.abs(a.x-b.x) < (a.w+b.w)/2 && Math.abs(a.y-b.y) < (a.h+b.h)/2; }
function loop(now) {
  if (!running) return;
  const dt = Math.min((now-lastTime)/1000, 0.035); lastTime = now;
  update(dt); draw(); requestAnimationFrame(loop);
}
function update(dt) {
  if (keys.ArrowLeft || keys.a || keys.A || keys.touchLeft) player.x -= player.speed*dt;
  if (keys.ArrowRight || keys.d || keys.D || keys.touchRight) player.x += player.speed*dt;
  if (keys.ArrowUp || keys.w || keys.W) player.y -= player.speed*dt;
  if (keys.ArrowDown || keys.s || keys.S) player.y += player.speed*dt;
  player.x = Math.max(22,Math.min(canvas.width-22,player.x));
  player.y = Math.max(35,Math.min(canvas.height-25,player.y));
  shotTimer -= dt;
  if ((keys[' '] || keys.touchFire) && shotTimer <= 0) { bullets.push({x:player.x,y:player.y-22,w:5,h:15,speed:510}); shotTimer=.18; }
  for (const b of bullets) b.y -= b.speed*dt;
  bullets = bullets.filter(b=>b.y>-20);
  enemyTimer -= dt;
  if (enemyTimer<=0) { enemies.push({x:35+Math.random()*(canvas.width-70),y:-25,w:30,h:30,speed:90+Math.random()*80}); enemyTimer=Math.max(.28,.85-score/1800); }
  for (const e of enemies) e.y += e.speed*dt;
  for (const b of bullets) for (const e of enemies) if (!b.dead && !e.dead && hit(b,e)) { b.dead=true;e.dead=true;score+=100; }
  bullets = bullets.filter(b=>!b.dead);
  for (const e of enemies) {
    if (!e.dead && hit({x:player.x,y:player.y,w:player.w,h:player.h},e)) { e.dead=true;lives--; }
    else if (!e.dead && e.y>canvas.height+25) { e.dead=true;lives--; }
  }
  enemies=enemies.filter(e=>!e.dead);
  for(const s of stars){s.y+=s.v*dt;if(s.y>canvas.height){s.y=0;s.x=Math.random()*canvas.width;}}
  updateHud();
  if(lives<=0) endGame();
}
function draw() {
  ctx.fillStyle='#080b18';ctx.fillRect(0,0,canvas.width,canvas.height);
  const g=ctx.createRadialGradient(450,270,20,450,270,600);g.addColorStop(0,'#17153b');g.addColorStop(1,'#080b18');ctx.fillStyle=g;ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle='#dce5ff';for(const s of stars){ctx.globalAlpha=.35+s.s/4;ctx.fillRect(s.x,s.y,s.s,s.s);}ctx.globalAlpha=1;
  ctx.strokeStyle='#6a5dff18';ctx.lineWidth=1;for(let x=0;x<canvas.width;x+=60){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,canvas.height);ctx.stroke();}
  for(const b of bullets){ctx.shadowBlur=12;ctx.shadowColor='#5ff5e6';ctx.fillStyle='#5ff5e6';ctx.fillRect(b.x-2,b.y,b.w,b.h);}ctx.shadowBlur=0;
  for(const e of enemies)drawEnemy(e);
  if(player)drawShip(player.x,player.y);
}
function setKey(key, down) { keys[key] = down; }
window.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();setKey(e.key,true);if(!running&&e.key==='Enter')startGame();});
window.addEventListener('keyup',e=>setKey(e.key,false));
startBtn.addEventListener('click',startGame);
function holdButton(id,key){const el=document.getElementById(id);el.addEventListener('pointerdown',e=>{e.preventDefault();keys[key]=true;});['pointerup','pointerleave','pointercancel'].forEach(ev=>el.addEventListener(ev,()=>keys[key]=false));}
holdButton('left','touchLeft');holdButton('right','touchRight');holdButton('fire','touchFire');
resetGame();draw();
